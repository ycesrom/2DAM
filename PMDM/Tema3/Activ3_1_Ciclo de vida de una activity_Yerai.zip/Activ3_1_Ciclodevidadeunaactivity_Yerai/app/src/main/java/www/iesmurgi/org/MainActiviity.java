package www.iesmurgi.org;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class MainActiviity extends Activity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("LIFECICLE", "onCreate");
    }
    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d("LIFECICLE","On start");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d("LIFECICLE","on resume");
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        Log.d("LIFECICLE","on pause");

    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.d("LIFECICLE","on resume");

    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d("LIFECICLE","on stop");

    }

    @Override
    protected void onDestroy()
    {
    super.onDestroy();
    Log.d("LIFECICLE","on Destroy");
    }
}
