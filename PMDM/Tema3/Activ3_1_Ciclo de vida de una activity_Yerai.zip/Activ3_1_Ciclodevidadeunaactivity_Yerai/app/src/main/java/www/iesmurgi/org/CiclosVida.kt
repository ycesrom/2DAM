package www.iesmurgi.org

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

class CiclosVida : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GreetingPreview()

            }
        }

    // Funcion que se llama cuando la app se inicia
    override fun onStart()
    {
        super.onStart()
        Log.i("LIFECYCLE", "onStart")
    }

    // Funcion que se llama cuando la app termina
    override fun onStop()
    {
        super.onStop()
        Log.d("LIFECYCLE", "onStop")
    }

    // Funcion que se llama cuando la app termina
    override fun onResume() {
        super.onResume()
        Log.d("LIFECICLE","OnResume")
    }

    // Funcion que se llama cuando la app termina
    override fun onPause() {
        super.onPause()
        Log.d("LIFECICLE","OnResume")

    }

    // Funcion que se llama cuando la app termina
    override fun onDestroy() {
        super.onDestroy()
        Log.d("LIFECICLE","OnResume")

    }

    // Funcion que se llama cuando la app termina
    override fun onRestart() {
        super.onRestart()
        Log.d("LIFECICLE","OnResume")

    }

}
    @Composable
    fun ver()
    {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally)
    {
        Text("Yerai")
    }
    }


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
ver()
}