package www.iesmurgi.org;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("LIFECICLE", "onCreate");
        //Esta linea obtiene un objeto button que nos permite interactual con el.
        //Se obtiene a partir del id que se ha establecido y se accede por la
        //clase R.
        Button btnaceptar = (Button) findViewById(R.id.btnaceptar);
        btnaceptar.setOnClickListener(new View.OnClickListener() {
            //Metodo que se llama cuando se haga click en el componente
            @Override
            public void onClick(View arg0) {
                TextView texto = (TextView)findViewById(R.id.txttexto);
                EditText edt = (EditText)findViewById(R.id.edtnombre);
                String nombre = edt.getText().toString();
                texto.setText("Hola "+nombre);
            }
        });
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d("LIFECICLE","On start");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d("LIFECICLE","on resume");
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        Log.d("LIFECICLE","on pause");

    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.d("LIFECICLE","on resume");

    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d("LIFECICLE","on stop");

    }

    @Override
    protected void onDestroy()
    {
    super.onDestroy();
    Log.d("LIFECICLE","on Destroy");
    }
}
