package www.iesmurgi.org

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import www.iesmurgi.org.ui.theme.U5_Proyect2_ToolBar_YeraiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            U5_Proyect2_ToolBar_YeraiTheme {
                // Llama a la funcion myScaffold que contiene un toolbar
                MyScaffold()
                /*Scaffold(topBar = { MiToolBar() }, content = { paddingValues ->
                     Column(
                         modifier = Modifier
                             .padding(paddingValues)
                             .fillMaxSize()
                     ) {
                         MisBotones()
                     }
                 })*/
                //Añade un ToolBar que esta creado en una funcion composable
                /*Scaffold(topBar = { MiToolBar() }, content = { paddingValues ->
                    Column(
                        modifier = Modifier
                            .padding(paddingValues)
                            .fillMaxSize()
                    ) {
                        MisBotones()
                    }
                })*/
                }
            }
        }
    }

@Composable
fun MyScaffold() {


    Scaffold(
        topBar = { MiToolBar() },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
            ) {
                MisBotones()
            }
        })

}

@Composable
fun MiText(modifier: Modifier = Modifier) {
    Column(
        Modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(text = "Esto es un ejemplo")
        Text(text = "Esto es un ejemplo", color = Color.Cyan)
        Text(text = "Esto es un ejemplo", fontWeight = FontWeight.ExtraBold)
        Text(text = "Esto es un ejemplo", fontWeight = FontWeight.W200)
        Text(text = "Esto es un ejemplo", style = TextStyle(fontFamily = FontFamily.Cursive))
        Text(
            text = "Esto es un ejemplo",
            style = TextStyle(textDecoration = TextDecoration.LineThrough)
        )
        Text(
            text = "Esto es un ejemplo",
            style = TextStyle(textDecoration = TextDecoration.Underline)
        )
        Text(
            text = "Esto es un ejemplo", style = TextStyle(
                textDecoration = TextDecoration.combine(
                    listOf(TextDecoration.Underline, TextDecoration.LineThrough)
                ),
                color = Color.Red,
                fontSize = 25.sp
            )
        )
    }
}

@Composable
fun MiOutlinedTextField(modifier: Modifier) {

    //rememberSabeable guarda el estado después de una recomposiciones o cambios de configuración
    var valor by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        OutlinedTextField(
            value = valor,
            onValueChange = {
                if (it.contains('a')) {
                    valor = it.replace("a", "")
                } else {
                    valor = it
                }
            },
            label = { Text("Ejemplo") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(red = 1f, green = 0.5f, blue = 0.2f),
                focusedBorderColor = Color.Red,
                focusedLabelColor = Color.Cyan,
                unfocusedLabelColor = Color.Yellow
            )
        )

    }

}

@Composable
fun MiTextField(modifier: Modifier = Modifier) {

    var valor by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        TextField(
            value = valor,
            onValueChange = {
                if (it.contains('a')) {
                    valor = it.replace("a", "")
                } else {
                    valor = it
                }
            },
            label = { Text(text = "Dime tu nombre") }
        )

    }

}
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    U5_Proyect2_ToolBar_YeraiTheme {
       MyScaffold()
    }
}