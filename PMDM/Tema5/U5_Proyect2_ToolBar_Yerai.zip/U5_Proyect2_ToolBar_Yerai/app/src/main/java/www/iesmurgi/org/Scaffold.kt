@file:OptIn(ExperimentalMaterial3Api::class)

package www.iesmurgi.org

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Preview
@Composable
fun ToolBar() {

    Scaffold(
        Modifier
            .height(50.dp)
            .fillMaxWidth()
            .background(Color.Gray)
    ) { it }

}

//Funcion que contiene el toolbar
@Preview
@Composable
fun MiToolBar() {

    TopAppBar(
        title = { Text("Mi primer ToolBar") },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Red,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.Blue,
            actionIconContentColor = Color.Cyan
        ),
        navigationIcon = {
            IconButton(onClick = {}) {
                Icon(imageVector = Icons.Filled.ArrowDropDown, contentDescription = "Contenido")
            }
        },
        actions = {
            IconButton(onClick = {}) {
                Icon(imageVector = Icons.Filled.Search, contentDescription = "Contenido")
            }
            IconButton(onClick = {}) {
                Icon(imageVector = Icons.Filled.AddCircle, contentDescription = "Contenido")
            }
            IconButton(onClick = {}) {
                Icon(imageVector = Icons.Filled.Home, contentDescription = "Contenido")
            }
        }

        )

}