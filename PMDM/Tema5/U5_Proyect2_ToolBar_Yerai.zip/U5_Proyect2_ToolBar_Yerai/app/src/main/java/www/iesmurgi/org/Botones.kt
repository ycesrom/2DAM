package www.iesmurgi.org

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Preview
@Composable
fun MisBotones(modifier: Modifier = Modifier) {

    var activo by rememberSaveable {mutableStateOf(true)}
    Column(
        Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        
        OutlinedButton(onClick = {activo = false}) {
            Text("OutlinedButon")
        }
        Button(onClick = {}, content = {
            Text("Boton 1")
        })
        Button(onClick = {activo = false}, colors = ButtonDefaults.buttonColors(
            containerColor = Color.Cyan,
            contentColor = Color.Blue,
            disabledContainerColor = Color.Green,
            disabledContentColor = Color(red = 1f, green = 1f, blue = 1f)
        ),
            border = BorderStroke(4.dp, Color.DarkGray),
            enabled = activo
        ) {
            Text("Boton 2")
        }

    }

}

@Preview
@Composable
fun MiBotoncillo(modifier: Modifier = Modifier) {

    Column(
        Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Button(
            onClick = {},
            enabled = false,
            colors = ButtonDefaults.buttonColors(
                disabledContentColor = Color.Cyan,
                disabledContainerColor = Color(
                    red = 1f,
                    green = 0.5f,
                    blue = 0.2f
                )
            )
        ) {
            Text("Botoncillo")
        }


    }

}

@Preview
@Composable
fun MiBoton(modifier: Modifier = Modifier) {

    Column(
        Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        FilledTonalButton(onClick = {}) {
            Text("Boton")
        }


    }

}

@Preview
@Composable
fun MiBotonElevado() {

    Column(
        Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        ElevatedButton(onClick = {}) {
            Text("Boton elevado")
        }


    }

}