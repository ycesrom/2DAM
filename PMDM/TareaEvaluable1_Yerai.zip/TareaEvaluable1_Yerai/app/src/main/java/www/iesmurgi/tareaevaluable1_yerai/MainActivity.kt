@file:OptIn(ExperimentalMaterial3Api::class)

package www.iesmurgi.tareaevaluable1_yerai

import android.app.Activity
import android.os.Bundle
import android.provider.CalendarContract.Colors
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import www.iesmurgi.tareaevaluable1_yerai.ui.theme.TareaEvaluable1_YeraiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TareaEvaluable1_YeraiTheme {
              GreetingPreview()
            }
        }
    }
}

@Composable
fun Superior()
{


val activity= LocalContext.current as Activity
    TopAppBar(
        title = { Text("Yerai Cespedes") },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Cyan,
            titleContentColor = Color.Black, navigationIconContentColor = Color.White,
            actionIconContentColor = Color.Black),
        navigationIcon =
        {
            IconButton(onClick = {})
        {

        }

        },
        actions =
        {
            IconButton(onClick = {})
            {
                Icon(imageVector = Icons.Filled.Close, contentDescription = "Cerrar",
                    modifier = Modifier
                    .clickable { activity.finish() })
            }

        }
    )
}
@Composable
fun Intermedia()
{

}

@Composable
fun Body(){
    Column(modifier = Modifier.fillMaxSize())
    {   val image1= painterResource(R.drawable.insta)
        Superior()
        Spacer(modifier = Modifier.height(150.dp))

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center)
        { Image(painter = image1, contentDescription = "Imagen Instagram")
        }
        Spacer(modifier = Modifier.height(20.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center)
        {
            Email()
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly)
        {
            Password()
        }
        Spacer(modifier = Modifier.height(10.dp))


        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.End)
        {
          OlvidoPass()
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center)
        {
           BotonLogin()
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center)
        {
            FBLogin()
        }


        Inferior()




    }





}

@Composable
fun Logo()
{

}

@Composable
fun Email()
{
    var email by remember { mutableStateOf("") }
    OutlinedTextField(value =email , onValueChange = {email=it},label ={ Text("Phone number, username or email") })

}

@Composable
fun Password()
{
    var password by remember { mutableStateOf("") }
    OutlinedTextField(value =password , onValueChange = {password=it},label ={ Text("Password") })

}

@Composable
fun OlvidoPass()
{
    Button(onClick = {}, modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(
            disabledContentColor = Color.White,
            disabledContainerColor = Color.White
        ) )
    {
        Text("Forgot password?",color = Color.Cyan)


    }

}

@Composable
fun BotonLogin()
{
    Button(onClick = {}, modifier = Modifier.fillMaxWidth()
        .padding(horizontal = 4.dp),
        colors = ButtonDefaults.buttonColors(
        disabledContentColor = Color.White,
        disabledContainerColor = Color.Cyan
    ),
        enabled = false)
    {
        Text("Log in",color = Color.White)

    }

    Spacer(modifier = Modifier.height(10.dp))




}

@Composable
fun OtroLogin(){}

@Composable
fun FBLogin()
{
    val image2= painterResource(R.drawable.fb)

    Image(painter = image2, contentDescription = "Facebook Login", modifier = Modifier
        .size(30.dp))
    Text("Continue as Yerai")

}


@Composable
fun Inferior()
{ val misOpciones = getOpciones(listOf("Leer y aceptar las politicas de usuario", "Deseo recibir informacion por email"
    , "Acepto todas las cookies" ))

    misOpciones.forEach {misOpciones->
        MiCheckBox(misOpciones)

    }



}
@Composable
fun MiCheckBox(checkInfo: MiDataClass) {

    /*var estadoCheckBox by rememberSaveable {
        mutableStateOf(true)
    }*/




    Checkbox(
        checked = checkInfo.opcion,
        onCheckedChange = { checkInfo.onCheckedChange(!checkInfo.opcion) },
        enabled = true,
        colors = CheckboxDefaults.colors(
            checkedColor = Color.Red,
            uncheckedColor = Color.Black,
            checkmarkColor = Color.Green,
            disabledCheckedColor = Color.Magenta,
            disabledUncheckedColor = Color.Yellow
        )
    )



    Text(text = checkInfo.titulo)

}
@Composable
fun getOpciones(titulos: List<String>):List<MiDataClass> {

    return titulos.map { indice ->

        var estado by rememberSaveable {
            mutableStateOf(true)
        }

        //Creamos objeto data class
        MiDataClass(
            titulo = "$indice",
            opcion = estado,
            /*onCheckedChange = { estado = it }*/
            onCheckedChange = {miNuevoEstado -> estado = miNuevoEstado}
        )

    }

}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
 Body()
}