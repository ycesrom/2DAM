package www.iesmurgi.tareaevaluable1_yerai

data class MiDataClass(val titulo:String,var opcion:Boolean,var onCheckedChange:(Boolean)->Unit)
{

}
