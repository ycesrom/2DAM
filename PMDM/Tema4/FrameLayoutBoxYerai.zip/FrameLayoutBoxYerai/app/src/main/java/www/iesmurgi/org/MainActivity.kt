package www.iesmurgi.org

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity()
{
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent{
            FrameLayout()
            }
        }
    }


// Creamos la funcion frameLayout
@Composable
fun FrameLayout()
{

    // Box con todas las filas
    Box(
        modifier= Modifier
            .fillMaxSize() // Hace que el box ocupe todo el tamaño disponible
            .background(Color.White),// Establecemos el color del box
        contentAlignment= Alignment.Center// Centramos el contenido
    ){
        // Fila superior con 3 elementos alineados en la parte superior
        Row(
            modifier = Modifier
                .fillMaxWidth()// Hacemos que row ocupe todo el ancho de la pantalla
                .align(Alignment.TopCenter) // Alineamos la fila en la parte superior y centrada horizontalmente
                .padding(20.dp),// Aplicamos un margen de 20 dp aldrededor de la fila
            horizontalArrangement= Arrangement.SpaceBetween // Separamos los elementos en el espacio horizontal


        )
        {

            BoxTexto("Left | Top") // Añadimos texto en la parte izquierda
            BoxTexto("Center Horizontal | Top")  // Añadimos texto en la parte central
            BoxTexto("Right | Top") // Añadimos texto en la parte derecha
        }
        // Fila Central con 3 elementos alineados en la parte central
        Row(
            modifier = Modifier
                .fillMaxWidth()// Hacemos que row ocupe todo el ancho de la pantalla
                .align(Alignment.Center),// Alineamos la fila en la parte centrar y centrada verticalmente
            horizontalArrangement= Arrangement.SpaceBetween // Separamos los elementos en el espacio horizontal
        )
        {
            BoxTexto("Center Vertical Left") // Añadimos texto en la parte izquierda
            BoxTexto("Center ") // Añadimos texto en la parte central
            BoxTexto("Center ") // Añadimos texto en la parte derecha


        }
        // Fila inferior con 3 elementos alineados en la parte inferior
        Row(
            modifier=Modifier
                .fillMaxWidth()// Hacemos que row ocupe todo el ancho de la pantalla
                .align(Alignment.BottomCenter),// Alineamos la fila en la parte inferior y centrada horizontalmente
                    horizontalArrangement= Arrangement.SpaceBetween // Separamos los elementos en el espacio horizontal

        )
        {
            BoxTexto("Left | Bottom") // Añadimos texto en la parte izquierda
            BoxTexto("Center Horizontal | Bottom") // Añadimos texto en la parte central
            BoxTexto("Right | Bottom") // Añadimos texto en la parte derecha

        }


    }
}

// Creamos la funcion boxTexto con dos parametros un String, y texto en Negrita
@Composable
fun BoxTexto(texto:String, fontWeight: FontWeight=FontWeight.Bold)
{
    Box ( modifier = Modifier
        .size(100.dp) // Definemos un tamaño fijo de 100 dp para el box.
    )
    {
        Text(text= texto,// El texto que le pasamos como parametro
            fontSize = 18.sp,// Tamaño de la letra la pondremos a 18 sp
            color = (Color.Black),// Color de la letra sera Negro
        fontWeight=fontWeight,// El texto se pondra en negrita
        modifier=Modifier.padding(6.dp)
            // Le pondremos un margen de 6 dp
        )
    }
}

//Funcion para que podamos previsualizarlo
@Preview(showBackground = true)
@Composable
fun BoxLayout()
{
    // Llamamos a la funcion frameLayout()
    FrameLayout()
}