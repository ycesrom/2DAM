package www.iesmurgi.examenapp

data class DataClassP(val titulo:String,var opcion:Boolean,var onCheckedChange:(Boolean)->Unit)
{

}