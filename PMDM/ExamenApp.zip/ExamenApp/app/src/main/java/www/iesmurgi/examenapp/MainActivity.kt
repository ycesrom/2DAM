@file:OptIn(ExperimentalMaterial3Api::class)

package www.iesmurgi.examenapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GreetingPreview()

                }
            }
        }

@Composable
fun formulario()
{
    Column(modifier = Modifier.fillMaxSize())
    {
        val image= painterResource(R.drawable.f1)
        var nombre by remember { mutableStateOf("") }
        var contraseña by remember { mutableStateOf("") }
        var switch1 by remember { mutableStateOf(true) }
        var switch2 by remember { mutableStateOf(true) }
        var switch3 by remember { mutableStateOf(true) }
        Spacer(modifier = Modifier.height(40.dp))
        TopAppBar(
            title = { Text("Mi primera toolbar") },
            colors = TopAppBarDefaults.topAppBarColors(containerColor =Color.Red,
                titleContentColor = Color.Green, navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White),
            navigationIcon =
            {
                IconButton(onClick = {})
                {
                    Icon(imageVector=Icons.Filled.Email,contentDescription="Email")
                }
            },
            actions =
            {
                IconButton(onClick = {})
                {
                    Icon(imageVector = Icons.Filled.Search, contentDescription = "Buscar")
                }

            }
        )
        Spacer(modifier = Modifier.height(20.dp))
        Row (modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly)
        {
            circularImage(image)
            rectangularImage(image)





        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly)
        {
            TextField(value = nombre, onValueChange = {nombre=it}, label ={ Text("Nombre") } )


        }
        Spacer(modifier = Modifier.height(20.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly)
        {  TextField(value = contraseña, onValueChange = {contraseña=it}, label ={ Text("Contraseña") } ) }

        Spacer(modifier = Modifier.height(20.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly)
        {
            Button(onClick = {}) {
                Text("Iniciar sesión")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly)
        {
            Switch(checked = switch1, onCheckedChange = {switch1=it}, thumbContent =
            {
                if(switch1)
                {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = Color.Green)

                }else
                {
                    
                    Icon(Icons.Filled.Done, contentDescription = null, tint = Color.Red)
                }
            })

            Switch(checked = switch2, onCheckedChange = {switch2=it}, thumbContent =
            {
                if(switch2)
                {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = Color.Green)

                }else
                {
                    Icon(Icons.Filled.Done, contentDescription = null, tint = Color.Red)
                }
            })
            Switch(checked = switch3, onCheckedChange = {switch3=it}, thumbContent =
            {
                if(switch3)
                {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = Color.Green)

                }else
                {
                    Icon(Icons.Filled.Done, contentDescription = null, tint = Color.Red)
                }
            })

        }
        val opciones = listOf("Opción 1", "Opción 2", "Opción 3")
        val misOpciones = getOpciones(listOf("Opción 1", "Opción 2", "Opción 3"))
        var opcionSeleccionada by remember { mutableStateOf(opciones[0]) }

opciones.forEach() { opcion ->
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        RadioButton(
            selected = opcionSeleccionada == opcion ,
            onClick = {  opcionSeleccionada = opcion
              }
        )
        Text(text = opcion)
    }
}
    }

}

@Composable
fun circularImage(image1:Painter)
{
    Image(painter =image1, contentDescription = null, modifier = Modifier.clip(CircleShape),
        contentScale = ContentScale.Crop)

}

@Composable
fun rectangularImage(image2:Painter)
{
    Image(painter = image2, contentDescription = null, modifier = Modifier.clip(RectangleShape),
        contentScale = ContentScale.FillWidth)

}

@Composable
fun normalImage(image3:Painter)
{
    Image(painter = image3, contentDescription = null)
}

@Composable
fun getOpciones(titulos: List<String>):List<DataClassP> {

    return titulos.map { indice ->

        var estado by rememberSaveable {
            mutableStateOf(true)
        }

        //Creamos objeto data class
        DataClassP(
            titulo = "$indice",
            opcion = estado,
            /*onCheckedChange = { estado = it }*/
            onCheckedChange = {miNuevoEstado -> estado = miNuevoEstado}
        )

    }

}




@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    formulario()

}