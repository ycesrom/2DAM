package www.iesmurgi.examenapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun MiCheckBox(checkInfo: DataClassP) {

    /*var estadoCheckBox by rememberSaveable {
        mutableStateOf(true)
    }*/



        Checkbox(
            checked = checkInfo.opcion,
            onCheckedChange = { checkInfo.onCheckedChange(!checkInfo.opcion) },
            enabled = true,
            colors = CheckboxDefaults.colors(
                checkedColor = Color.Red,
                uncheckedColor = Color.Black,
                checkmarkColor = Color.Green,
                disabledCheckedColor = Color.Magenta,
                disabledUncheckedColor = Color.Yellow
            )
        )



        Text(text = checkInfo.titulo)

    }

