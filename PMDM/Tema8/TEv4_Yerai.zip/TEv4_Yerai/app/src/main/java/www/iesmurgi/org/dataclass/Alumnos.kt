package www.iesmurgi.org.data

import androidx.annotation.DrawableRes


data class Alumnos(
    val nombre: String,
    val email: String,
    val asignatura: String,
     @DrawableRes val foto: Int
)

