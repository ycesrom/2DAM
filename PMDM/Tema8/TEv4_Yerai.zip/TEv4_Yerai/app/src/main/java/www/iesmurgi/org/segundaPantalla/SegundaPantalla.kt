package www.iesmurgi.org.segundaPantalla

import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import android.annotation.SuppressLint
import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarColors
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import www.iesmurgi.org.R

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun SegundaPantalla(navController: NavController, name: String, email: String, contador:Int) {
    var inputName by rememberSaveable { mutableStateOf(name) }
    var inputEmail by rememberSaveable { mutableStateOf(email) }
    val context = LocalContext.current
    val activity = context as? Activity



    Scaffold(
        topBar = {
            TopAppBar(
                title = {Text(
                    text = "Yerai",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()

                )},

                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )



            )
        }

    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Spacer(modifier = Modifier.padding(60.dp))


            OutlinedTextField(
                value = inputName,
                onValueChange = { inputName = it },
                label = { Text(stringResource(R.string.nombre_label)) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = inputEmail,
                onValueChange = { inputEmail = it },
                label = { stringResource(R.string.email_label) }
            )

            Spacer(modifier = Modifier.height(16.dp))

        Row {
            Button(
                onClick = {
                    inputName = ""
                    inputEmail = ""
                    Toast.makeText(context, "Campos limpiados", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(stringResource(R.string.limpiar_button))
            }
            Spacer(modifier = Modifier.width(8.dp))



            Button(
                onClick = { activity?.finishAffinity() },
                modifier = Modifier.fillMaxWidth()
                       .weight(1f)
            ) {
                Text(stringResource(R.string.salir_button))
            }
        }
            Spacer(modifier = Modifier.height(16.dp))
            Text(stringResource(R.string.contador_alumnos))
            Text(" $contador", fontWeight = FontWeight.Bold, fontSize = 18.sp)

    }
}}

