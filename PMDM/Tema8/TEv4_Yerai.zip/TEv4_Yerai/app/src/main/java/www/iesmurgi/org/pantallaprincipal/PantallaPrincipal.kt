package www.iesmurgi.org.pantallaprincipal

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import www.iesmurgi.org.R
import www.iesmurgi.org.data.Alumnos

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaAlumnos(navController: NavController) {
    var contador by rememberSaveable { mutableStateOf(0) } // Contador Local


    val alumnos = listOf(
        Alumnos("Ayman", "Matemáticas", "Ayman@example.com", R.drawable.aymancharchaoui),
        Alumnos("Bernardo", "Ciencias", "Bernardo@example.com", R.drawable.bernardorodriguezlinares),
        Alumnos("Ruben", "Historia", "Ruben@example.com", R.drawable.fotoruben),
        Alumnos("Alexandru", "Lengua", "Alex@example.com", R.drawable.alexandruanutapreda),
        Alumnos("Jose", "Arte", "Jose@example.com", R.drawable.img20241111222727),
        Alumnos("Marco", "Música", "Marco@xample.com", R.drawable.img20240923143611),
        Alumnos("Jose", "Educación Física", "jose@example.com", R.drawable.img20241016163828),
        Alumnos("Javier Campoy", "Informática", "javi@example.com", R.drawable.javiecampoylozano),
        Alumnos("Jorge", "Filosofía", "jorge@example.com", R.drawable.jorgevizcainomaldonado),
        Alumnos("Oscar", "Química", "oscar@example.com", R.drawable.oscarabellan),
        Alumnos("Walther", "Física", "walther@example.com", R.drawable.waltheralexandro),
        Alumnos("Lubo", "Biología", "lubo@example.com", R.drawable.whatsappimage20240923143650),
        Alumnos("Vilian", "Geografía", "vilian@example.com", R.drawable.whatsappimage20241030132125),
        Alumnos("Alessia", "Economía", "alessia@example.com", R.drawable.alessiaoliveratorres),
        Alumnos("Angel", "Tecnología", "angel@example.com", R.drawable.angelfloro),
        Alumnos("Angel M.", "Inglés", "angelm@example.com", R.drawable.angelmiguelmunoz),
        Alumnos("Clara", "Francés", "clara@example.com", R.drawable.clararoldanperez),
        Alumnos("Moha F.", "Alemán", "mohaf@example.com", R.drawable.farismohamedamine),
        Alumnos("Moha A.", "Italiano", "moha.a@example.com", R.drawable.foto),
        Alumnos("Javier", "Japonés", "javiercortes@example.com", R.drawable.javiercortes),
        Alumnos("Juanra", "Francés", "juanra@example.com", R.drawable.juanramonpereztoledo),
        Alumnos("Lucia", "Alemán", "lucia@example.com", R.drawable.lucia),
        Alumnos("Oscar B", "Italiano", "oscarb@example.com", R.drawable.oscarbono),
        Alumnos("Sergey", "Japonés", "sergey@example.com", R.drawable.sergeytereshkov),
        Alumnos("Yerai", "Francés", "yerai@example.com", R.drawable.yerai)
    )



    Column {

        Spacer(modifier = Modifier.padding(30.dp))
        Text(
            text = stringResource(R.string.lista_alumnos),
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(20.dp)

        )


        LazyColumn {

            items(alumnos) { alumno ->
                StudentItem(alumno) {
                    contador++
                    navController.navigate("segundaPantalla/${alumno.nombre}/${alumno.email}/$contador")
                }
            }
        }
    }
}

@Composable
fun StudentItem(alumnos: Alumnos, onClick: () -> Unit) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            
            .clickable { onClick()

            }

            .border(1.dp, Color.Gray),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors=CardDefaults.cardColors(Color.Cyan)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = alumnos.foto),
                contentDescription = "Imagen de ${alumnos.nombre}",
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.size(16.dp))
            Column {
                Text(text = alumnos.nombre, fontWeight = FontWeight.Bold)
                Text(text = alumnos.asignatura)
                Text(text = alumnos.email)
            }
        }
    }
}
