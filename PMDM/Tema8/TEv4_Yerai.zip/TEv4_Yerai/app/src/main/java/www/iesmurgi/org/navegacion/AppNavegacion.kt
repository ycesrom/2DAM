package www.iesmurgi.org.navegacion

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import www.iesmurgi.org.pantallaprincipal.ListaAlumnos
import www.iesmurgi.org.segundaPantalla.SegundaPantalla

@Composable
fun AppNavegacion(){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "pantallaPrincipal" ) {
        composable("pantallaPrincipal") {
            ListaAlumnos(navController)
        }

        composable("segundaPantalla/{nombre}/{email}/{contador}") { backStackEntry ->
            val name = backStackEntry.arguments?.getString("nombre") ?: "Desconocido"
            val email = backStackEntry.arguments?.getString("email") ?: "Sin correo"
            val contadorActual = backStackEntry.arguments?.getString("contador")?.toIntOrNull() ?: 0

            SegundaPantalla(navController, name, email, contadorActual)
        }
    }

}