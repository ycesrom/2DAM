package com.example.ejemploropa.data

data class Ropa(
    val nombre: String,
    val precio: Double,
    val talla: String,
    val imagen: Int // Resource ID for the image
)
