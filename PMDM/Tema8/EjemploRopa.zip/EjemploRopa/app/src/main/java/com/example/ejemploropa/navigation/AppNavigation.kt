package com.example.ejemploropa.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ejemploropa.screens.login.LoginScreen
import com.example.ejemploropa.screens.shop.SecondScreen
import com.example.ejemploropa.screens.shop.ShopScreen

enum class AppScreens {
    LoginScreen,
    ShopScreen,
    SecondScreen
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = AppScreens.LoginScreen.name) {
        composable(AppScreens.LoginScreen.name) {
            LoginScreen(navController = navController)
        }
        composable(AppScreens.ShopScreen.name) {
            ShopScreen(navController = navController)
        }
        composable(
            route = "${AppScreens.SecondScreen.name}/{precio}/{nombre}",
            arguments = listOf(
                navArgument("precio") { type = NavType.StringType },
                navArgument("nombre") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val precio = backStackEntry.arguments?.getString("precio") ?: "No disponible"
            val nombre = backStackEntry.arguments?.getString("nombre") ?: "No disponible"
            SecondScreen(navController = navController, precio = precio, nombre = nombre)
        }
    }
}


