package com.example.ejemploropa.screens.shop

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.ejemploropa.R
import com.example.ejemploropa.data.Ropa

class    ShopViewModel : ViewModel() {
    val ropaList = mutableStateListOf<Ropa>()

    init {
        loadRopa()
    }

    private fun loadRopa() {
        ropaList.addAll(
            listOf(
                Ropa("Camiseta", 25.99, "M", R.drawable.camiseta),
                Ropa("Pantalón", 49.99, "L", R.drawable.pantalon),
                Ropa("Zapatos", 79.99, "42", R.drawable.zapatos),
                Ropa("Gorra", 15.99, "Unica", R.drawable.gorra),
                Ropa("Sudadera", 39.99, "S", R.drawable.ic_launcher_foreground),
                Ropa("Calcetines", 9.99, "M", R.drawable.ic_launcher_foreground),
                Ropa("Chaqueta", 59.99, "XL", R.drawable.ic_launcher_foreground),
                Ropa("Bufanda", 19.99, "Unica", R.drawable.ic_launcher_foreground),
                Ropa("Guantes", 12.99, "M", R.drawable.ic_launcher_foreground),
                Ropa("Cinturon", 22.99, "L", R.drawable.ic_launcher_foreground),
            )
        )
    }
}