package com.example.ejemploropa.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.example.ejemploropa.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomTopAppBar(
    title: String,
    menuIcon: ImageVector,
    onMenuClick: () -> Unit,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {},
    navController: NavController? = null,
    expanded: Boolean = false,
    onDismissRequest: () -> Unit = {},
    menuItems: List<String> = emptyList()
) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            if (showBackButton) {
                IconButton(onClick = {
                    if (navController != null) {
                        navController.popBackStack()
                    } else {
                        onBackClick()
                    }
                }) {
                    Icon(Icons.Filled.ArrowBack, stringResource(R.string.back))
                }
            }
        },
        actions = {
            Box(modifier = Modifier.wrapContentSize(Alignment.TopEnd)) {
                IconButton(onClick = onMenuClick) {
                    Icon(menuIcon, stringResource(R.string.menu))
                }
                if (menuItems.isNotEmpty()) {
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = onDismissRequest,
                        modifier = Modifier.wrapContentSize(Alignment.TopEnd)
                    ) {
                        menuItems.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(stringResource(id = when (item) {
                                    "Item 1" -> R.string.item_1
                                    "Item 2" -> R.string.item_2
                                    "Item 3" -> R.string.item_3
                                    else -> R.string.item_1
                                })) },
                                onClick = {
                                    onDismissRequest()
                                }
                            )
                        }
                    }
                }
            }
        }
    )
}