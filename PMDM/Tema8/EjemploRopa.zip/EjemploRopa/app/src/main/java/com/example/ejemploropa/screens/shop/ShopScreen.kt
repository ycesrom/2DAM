package com.example.ejemploropa.screens.shop

import android.content.res.Configuration
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.ejemploropa.R
import com.example.ejemploropa.data.Ropa
import com.example.ejemploropa.navigation.AppScreens
import com.example.ejemploropa.ui.components.CustomTopAppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(navController: NavController, shopViewModel: ShopViewModel = viewModel()) {
    var expanded by remember { mutableStateOf(false) }
    val menuItems = listOf("Item 1", "Item 2", "Item 3")
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val columns = if (isLandscape)  6 else 3

    Scaffold(
        topBar = {
            CustomTopAppBar(
                title = stringResource(R.string.shop_title),
                menuIcon = Icons.Filled.Menu,
                onMenuClick = { expanded = true },
                showBackButton = true,
                navController = navController,
                expanded = expanded,
                onDismissRequest = { expanded = false },
                menuItems = menuItems
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(shopViewModel.ropaList) { ropa ->
                ShopCard(ropa = ropa,navController)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopCard(ropa: Ropa,navController: NavController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = ropa.imagen),
                contentDescription = ropa.nombre,
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = ropa.nombre, style = MaterialTheme.typography.titleMedium)
            Text(text = stringResource(R.string.price, ropa.precio), style = MaterialTheme.typography.bodyMedium)
            Text(text = stringResource(R.string.size, ropa.talla), style = MaterialTheme.typography.bodyMedium)

            Button(onClick = { navController.navigate("${AppScreens.SecondScreen.name}/${ropa.precio}/${ropa.nombre}") }) {
                Text(text = "Volver" ) }
        }
    }
}